# GITHUB

## 项目开发者

[bmax](https://github.com/bmax121)





## 项目地址

[APatch](https://github.com/bmax121/APatch).

[kernelPatch](https://github.com/bmax121/kernelPatch).

## 交流群
[APatch中文组](https://t.me/APatch_CN_Group)
[APatch_]