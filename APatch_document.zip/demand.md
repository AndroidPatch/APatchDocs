# 安装要求

### 仅限 ARM64

### Android 内核版本 3.18 - 6.1

### 内核要求

****

CONFIG_KALLSYMS=y

CONFIG_KALLSYMS_ALL=y

CONFIG_KALLSYMS=y或CONFIG_KALLSYMS_ALL=n(早期支持)


**** 